//
//  Reachability.swift
//  SoccerTraccer
//
//  Created by Chris Carbajal on 11/17/18.
//  Copyright © 2018 Chris Carbajal. All rights reserved.
//
import UIKit
import Foundation
import SystemConfiguration
public class Reachability {                         //function checks for internet connection: true==yes, no==false
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr()
        zeroAddress.sa_len = UInt8(MemoryLayout<sockaddr>.size)
        zeroAddress.sa_family = sa_family_t(AF_INET)
        
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            SCNetworkReachabilityCreateWithAddress(nil, UnsafePointer($0))
        }) else { return false }
        
        var flags = SCNetworkReachabilityFlags()
        guard SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) else { return false }
        
        return flags.contains(.reachable) && !flags.contains(.connectionRequired)
    }
    
}
