//
//  StatsEntity+CoreDataClass.swift
//  SoccerTraccer
//
//  Created by Chris Carbajal on 11/6/18.
//  Copyright © 2018 Chris Carbajal. All rights reserved.
//
//

import Foundation
import CoreData


public class StatsEntity: NSManagedObject {

}
